USE ECOMMERCE;

USE ECOMMERCE;

SELECT * FROM CATEGORIES;
SELECT * FROM CUSTOMERS;
SELECT * FROM EMPLOYEES;
SELECT * FROM ORDERDETAILS;
SELECT * FROM ORDERS;
SELECT * FROM PRODUCTS;
SELECT * FROM SHIPPERS;
SELECT * FROM SUPPLIERS;

/*
1. Total Sales by Employee: 
   - Write a query to calculate the total sales (in dollars) made by each employee, 
   considering the quantity and unit price of products sold.
*/
-- ANSWER 1
SELECT E.EMPLOYEEID, E.FIRSTNAME, E.LASTNAME, SUM(OD.QUANTITY * OD.UNITPRICE) AS TOTALSALES
FROM EMPLOYEES E
INNER JOIN ORDERS O
ON E.EMPLOYEEID = O.EMPLOYEEID
INNER JOIN ORDERDETAILS OD
ON O.ORDERID = OD.ORDERID
GROUP BY E.EMPLOYEEID
ORDER BY TOTALSALES DESC;

/*
2. Top 5 Customers by Sales:
   - Identify the top 5 customers who have generated the most revenue. 
   Show the customer’s name and the total amount they’ve spent.
*/
-- ANSWER 2
SELECT C.CUSTOMERNAME, SUM(OD.QUANTITY * OD.UNITPRICE) AS AMOUNT_SPENT
FROM CUSTOMERS C
INNER JOIN ORDERS O 
ON C.CUSTOMERID = O.CUSTOMERID 
INNER JOIN ORDERDETAILS OD 
ON O.ORDERID = OD.ORDERID
GROUP BY C.CUSTOMERID
ORDER BY AMOUNT_SPENT DESC
LIMIT 5;

/*
3. Monthly Sales Trend:
   - Write a query to display the total sales amount for each month in the year 1997.
*/
-- ANSWER 3
SELECT YEAR(O.ORDERDATE) AS YEAR, MONTH(O.ORDERDATE) AS MONTH, SUM(OD.QUANTITY * OD.UNITPRICE) AS TOTAL_SALES
FROM ORDERS O 
INNER JOIN ORDERDETAILS OD
ON O.ORDERID = OD.ORDERID
WHERE YEAR(O.ORDERDATE) = 1997
GROUP BY YEAR(O.ORDERDATE), MONTH(O.ORDERDATE)
ORDER BY TOTAL_SALES DESC;

/*
4. Order Fulfillment Time:
   - Calculate the average time (in days) taken to fulfill an order (from `OrderDate` to `ShippedDate`) 
   for each employee.
*/
-- ANSWER 4
/*
SELECT E.EMPLOYEEID, E.FIRSTNAME, E.LASTNAME, AVG(DATEDIFF(O.SHIPPEDDATE, O.ORDERDATE)) AS AVG_FULFILLMENT_TIME
FROM EMPLOYEES E
INNER JOIN ORDERS O 
ON E.EMPLOYEEID = O.EMPLOYEEID
WHERE O.SHIPPEDDATE IS NOT NULL
GROUP BY E.EMPLOYEEID, E.FIRSTNAME, E.LASTNAME
ORDER BY AVG_FULFILLMENT_TIME;
*/

/*
 5. Products by Category with No Sales:
   - List the products in each category that have not been sold at all. 
*/
-- ANSWER 5

SELECT P.PRODUCTID, P.PRODUCTNAME, C.CATEGORYID, C.CATEGORYNAME 
FROM CATEGORIES C
INNER JOIN PRODUCTS P 
ON C.CATEGORYID = P.CATEGORYID
LEFT JOIN ORDERDETAILS OD
ON P.PRODUCTID = OD.PRODUCTID
WHERE OD.PRODUCTID IS NULL
ORDER BY C.CATEGORYNAME, P.PRODUCTNAME;


/*
6. Customers with Multiple Orders on the Same Date:
   - Write a query to find customers who have placed more than one order on the same date.
*/
-- ANSWER 6
SELECT C.CUSTOMERID, C.CUSTOMERNAME, O.ORDERDATE, COUNT(O.ORDERID) AS ORDER_COUNT
FROM CUSTOMERS C 
INNER JOIN ORDERS O 
ON C.CUSTOMERID = O.CUSTOMERID
GROUP BY C.CUSTOMERID, C.CUSTOMERNAME, O.ORDERDATE
HAVING COUNT(O.ORDERID) > 1
ORDER BY O.ORDERDATE, ORDER_COUNT DESC;

/*
7. Average Discount per Product:
   - Calculate the average discount given per product across all orders.
*/
-- ANSWER 7
SELECT P.PRODUCTID, P.PRODUCTNAME, AVG(OD.DISCOUNT) AS AVERAGE_DISCOUNT
FROM PRODUCTS P 
INNER JOIN ORDERDETAILS OD
ON P.PRODUCTID = OD.PRODUCTID
GROUP BY P.PRODUCTID, P.PRODUCTNAME
ORDER BY AVERAGE_DISCOUNT DESC;

/*
8. Products Ordered by Each Customer:
   - For each customer, list the products they have ordered along with the total quantity of each product ordered.
*/
-- ANSWER 8

SELECT C.CUSTOMERID, C.CUSTOMERNAME, P.PRODUCTNAME, SUM(OD.QUANTITY) AS TOTAL_QUANTITY
FROM CUSTOMERS C 
INNER JOIN ORDERS O 
ON C.CUSTOMERID = O.CUSTOMERID
INNER JOIN ORDERDETAILS OD
ON O.ORDERID = OD.ORDERID
INNER JOIN PRODUCTS P 
ON P.PRODUCTID = OD.PRODUCTID
GROUP BY C.CUSTOMERID, C.CUSTOMERNAME, P.PRODUCTNAME
ORDER BY TOTAL_QUANTITY DESC;

/*
9. Employee Sales Ranking:
   - Rank employees based on their total sales. Show the employeename, total sales, and their rank.
*/
-- ANSWER 9
SELECT E.EMPLOYEEID, CONCAT_WS(" ", LASTNAME, FIRSTNAME) AS EMPLOYEENAME, 
	SUM(OD.UNITPRICE * OD.QUANTITY) AS TOTAL_SALES,
	RANK() OVER (ORDER BY SUM(OD.UNITPRICE * OD.QUANTITY) DESC) AS SALES_RANK
FROM EMPLOYEES E 
INNER JOIN ORDERS O 
ON E.EMPLOYEEID = O.EMPLOYEEID
INNER JOIN ORDERDETAILS OD 
ON O.ORDERID = OD.ORDERID
GROUP BY E.EMPLOYEEID, EMPLOYEENAME
ORDER BY TOTAL_SALES;

/*
10. Sales by Country and Category:
    - Write a query to display the total sales amount for each product category, grouped by country.
*/
-- ANSWER 10
SELECT CA.CATEGORYID, CA.CATEGORYNAME, C.COUNTRY, SUM(OD.UNITPRICE * OD.QUANTITY) AS TOTALSALES
FROM CUSTOMERS C 
INNER JOIN ORDERS O 
ON C.CUSTOMERID = O.CUSTOMERID
INNER JOIN ORDERDETAILS OD
ON O.ORDERID = OD.ORDERID
INNER JOIN PRODUCTS P 
ON OD.PRODUCTID = P.PRODUCTID
INNER JOIN CATEGORIES CA
ON CA.CATEGORYID = P.CATEGORYID
GROUP BY C.COUNTRY, CA.CATEGORYID, CA.CATEGORYNAME
ORDER BY TOTALSALES DESC;

/*
11. Year-over-Year Sales Growth
*/
-- ANSWER 11
WITH YearlySales AS (
    SELECT YEAR(o.OrderDate) AS Year, 
           SUM(od.Quantity * od.UnitPrice) AS TotalSales
    FROM orders o
    JOIN orderdetails od ON o.OrderID = od.OrderID
    GROUP BY YEAR(o.OrderDate)
)
SELECT Year, 
       TotalSales, 
       LAG(TotalSales) OVER (ORDER BY Year) AS PreviousYearSales,
       CASE 
           WHEN LAG(TotalSales) OVER (ORDER BY Year) IS NULL THEN 0
           ELSE ((TotalSales - LAG(TotalSales) OVER (ORDER BY Year)) / LAG(TotalSales) OVER (ORDER BY Year)) * 100
       END AS YoYGrowth
FROM YearlySales
ORDER BY Year;


/*
12. Order Quantity Percentile:
	- Calculate the percentile rank of each order based on the total quantity of products in the order.
*/
-- ANSWER 12
WITH OrderQuantities AS (
    SELECT o.OrderID, 
           SUM(od.Quantity) AS TotalQuantity
    FROM orders o
    JOIN orderdetails od ON o.OrderID = od.OrderID
    GROUP BY o.OrderID
)
SELECT OrderID, 
       TotalQuantity, 
       PERCENT_RANK() OVER (ORDER BY TotalQuantity) AS QuantityPercentile
FROM OrderQuantities
ORDER BY QuantityPercentile;

/*
13. Products Never Reordered:
	- Identify products that have been sold but have never been reordered (ordered only once).
*/
-- ANSWER 13
SELECT P.PRODUCTID, P.PRODUCTNAME
FROM PRODUCTS P
INNER JOIN ORDERDETAILS OD ON P.PRODUCTID = OD.PRODUCTID
GROUP BY P.PRODUCTID, P.PRODUCTNAME
HAVING COUNT(DISTINCT OD.ORDERID) = 1
ORDER BY P.PRODUCTNAME;

/*
14. Most Valuable Product by Revenue:
	- Write a query to find the product that has generated the most revenue in eacg category.
*/
-- ANSWER 14
WITH ProductRevenue AS (
    SELECT c.CategoryID, 
           c.CategoryName, 
           p.ProductID, 
           p.ProductName, 
           SUM(od.Quantity * od.UnitPrice) AS TotalRevenue
    FROM categories c
    JOIN products p ON c.CategoryID = p.CategoryID
    JOIN orderdetails od ON p.ProductID = od.ProductID
    GROUP BY c.CategoryID, c.CategoryName, p.ProductID, p.ProductName
)
SELECT CategoryID, 
       CategoryName, 
       ProductID, 
       ProductName, 
       TotalRevenue
FROM (
    SELECT CategoryID, 
           CategoryName, 
           ProductID, 
           ProductName, 
           TotalRevenue, 
           ROW_NUMBER() OVER (PARTITION BY CategoryID ORDER BY TotalRevenue DESC) AS RevenueRank
    FROM ProductRevenue
) AS RankedProducts
WHERE RevenueRank = 1
ORDER BY CategoryID;

/*
15. Complex Order Details:
	- Identify orders where the total price of all items exceeds $100 and contains at least one product with a discount of 5% or more.
*/
-- ANSWER 15
SELECT o.OrderID,
       SUM(od.Quantity * od.UnitPrice * (1 - od.Discount)) AS TotalOrderPrice,
       MAX(od.Discount) AS MaxDiscount
FROM orders o
INNER JOIN orderdetails od ON o.OrderID = od.OrderID
GROUP BY o.OrderID
HAVING SUM(od.Quantity * od.UnitPrice * (1 - od.Discount)) > 100
   AND MAX(od.Discount) >= 0.05
ORDER BY TotalOrderPrice DESC;







